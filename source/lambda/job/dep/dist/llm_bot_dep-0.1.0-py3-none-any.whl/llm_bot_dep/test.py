import logging
from typing import List, Optional
from langchain.docstore.document import Document
from langchain.document_loaders.base import BaseLoader
import uuid
from datetime import datetime
# from docx import Document as pyDocument
import logging
import re
# import markdownify
from langchain.docstore.document import Document
from langchain.document_loaders.base import BaseLoader
# from loaders.docx import CustomDocLoaderlambda
# from loaders.html import CustomHtmlLoader


import logging
from typing import List, Optional
from langchain.docstore.document import Document
from langchain.document_loaders.base import BaseLoader
import mammoth
import uuid
from datetime import datetime
from docx import Document as pyDocument

logger = logging.getLogger(__name__)


import logging
import re
import markdownify
from langchain.docstore.document import Document
from langchain.document_loaders.base import BaseLoader

logger = logging.getLogger(__name__)


class CustomHtmlLoader(BaseLoader):
    """Load `HTML` files using `Unstructured`.

    You can run the loader in one of two modes: "single" and "elements".
    If you use "single" mode, the document will be returned as a single
    langchain Document object. If you use "elements" mode, the unstructured
    library will split the document into elements such as Title and NarrativeText.
    You can pass in additional unstructured kwargs after mode to apply
    different unstructured settings.

    """
    def __init__(
        self,
        aws_path: str
    ):
        """Initialize with file path."""
        self.aws_path = aws_path

    def clean_html(self, html_str: str) -> str:
        # Filter out DOCTYPE
        html_str = ' '.join(html_str.split())
        re_doctype = re.compile(r'<!DOCTYPE .*?>', re.S)
        s = re_doctype.sub('', html_str)

        # Filter out CDATA
        re_cdata = re.compile('//<!\[CDATA\[[^>]*//\]\]>', re.I)
        s = re_cdata.sub('', s)

        # Filter out script
        re_script = re.compile('<\s*script[^>]*>[^<]*<\s*/\s*script\s*>', re.I)
        s = re_script.sub('', s)

        # Filter out style
        re_style = re.compile('<\s*style[^>]*>[^<]*<\s*/\s*style\s*>', re.I)
        s = re_style.sub('', s)

        # Filter out HTML comments
        re_comment = re.compile('<!--[^>]*-->')
        s = re_comment.sub('', s)

        # Remove extra blank lines
        blank_line = re.compile('\n+')
        s = blank_line.sub('\n', s)

        # Remove blank image
        img_src = re.compile('<img src="" />')
        s = img_src.sub('', s)

        return s.strip()

    # def load(self, file_content: str) -> List[Document]:
    def load(self, file_content: str):
        file_content = self.clean_html(file_content)
        file_content = markdownify.markdownify(file_content, heading_style="ATX")
        doc = Document(page_content=file_content,
                       metadata={"file_type": "html", "file_path": self.aws_path})

        return doc


def process_html(html_str: str, **kwargs):
    bucket_name = kwargs["bucket"]
    key = kwargs["key"]
    loader = CustomHtmlLoader(aws_path=f"s3://{bucket_name}/{key}")
    doc = loader.load(html_str)
    splitter = MarkdownHeaderTextSplitter(kwargs['res_bucket'])
    doc_list = splitter.split_text(doc)

    return doc_list


class CustomMarkdownLoader(BaseLoader):
    """Load markdown file.

    Args:
        file_content: File content in markdown file.

        encoding: File encoding to use. If `None`, the file will be loaded
        with the default system encoding.

        autodetect_encoding: Whether to try to autodetect the file encoding
            if the specified encoding fails.
    """

    def __init__(
        self,
        aws_path: str,
        encoding: Optional[str] = None,
        autodetect_encoding: bool = False,
    ):
        """Initialize with file path."""
        self.aws_path = aws_path
        self.encoding = encoding
        self.autodetect_encoding = autodetect_encoding

    def load(self, content: str) -> Document:
        """Load from file path."""
        metadata = {"file_path": self.aws_path, "file_type": "md"}

        return Document(page_content=content, metadata=metadata)


class CustomDocLoader(BaseLoader):
    """Load docx file.

    Args:
        file_content: File content in docx file.

        encoding: File encoding to use. If `None`, the file will be loaded
        with the default system encoding.

        autodetect_encoding: Whether to try to autodetect the file encoding
            if the specified encoding fails.
    """

    def __init__(
        self,
        file_path: str,
        aws_path: str,
        encoding: Optional[str] = None,
        autodetect_encoding: bool = False,
    ):
        """Initialize with file path."""
        self.file_path = file_path
        self.aws_path = aws_path
        self.encoding = encoding
        self.autodetect_encoding = autodetect_encoding
    
    def clean_document(self, doc: pyDocument):
        """Clean document including removing header and footer for each page

        Args:
            doc (Document): The document to clean
        """
        # Remove headers and footers
        for section in doc.sections:
            if section.header is not None:
                for paragraph in section.header.paragraphs:
                    paragraph.clear()

            if section.footer is not None:
                for paragraph in section.footer.paragraphs:
                    paragraph.clear()

    def load(self) -> List[Document]:
        """Load from file path."""
        metadata = {"file_path": self.aws_path, "file_type": "docx"}

        def _convert_image(image):
            # Images are excluded
            return {"src": ""}
        
        pyDoc = pyDocument(self.file_path)
        self.clean_document(pyDoc)
        pyDoc.save(self.file_path)

        with open(self.file_path, "rb") as docx_file:
            result = mammoth.convert_to_html(docx_file, convert_image=mammoth.images.img_element(_convert_image))
            html_content = result.value
            loader = CustomHtmlLoader(aws_path=self.aws_path)
            doc = loader.load(html_content)
            doc.metadata = metadata

        return doc


def process_doc(s3, **kwargs):
    now = datetime.now()
    timestamp_str = now.strftime("%Y%m%d%H%M%S")
    random_uuid = str(uuid.uuid4())[:8]
    bucket_name = kwargs['bucket']
    key = kwargs['key']
    local_path = f'/tmp/doc-{timestamp_str}-{random_uuid}.docx'

    s3.download_file(bucket_name, key, local_path)
    loader = CustomDocLoader(file_path=local_path, aws_path=f"s3://{bucket_name}/{key}")
    doc = loader.load()
    splitter = MarkdownHeaderTextSplitter(kwargs['res_bucket'])
    doc_list = splitter.split_text(doc)

    return doc_list


def find_parent(headers: dict, level: int):
    """Find the parent node of current node
    Find the last node whose level is less than current node

    Args:
        headers (dict): headers dict
        level (int): level of the header, eg. # is level1, ## is level2

    Returns:
        _type_: parent node id or None
    """
    for id, header in reversed(list(headers.items())):
        if header["level"] < level:
            return id

    return None


def find_previous_with_same_level(headers: dict, level: int):
    """Find the previous node with same level

    Args:
        headers (dict): headers dict
        level (int): level of the header, eg. # is level1, ## is level2

    Returns:
        _type_: previous node id or None
    """
    for id, header in reversed(list(headers.items())):
        if header["level"] == level:
            return id

    return None


def find_next_with_same_level(headers: dict, header_id: str):
    level = headers[header_id]["level"]
    header_found = False

    for id, header in headers.items():
        if header_id == id:
            header_found = True

        # Find the next node with the same level
        if header_found and header["level"] == level and header_id != id:
            return id

    return None


def find_child(headers: dict, header_id: str):
    children = []
    level = headers[header_id]["level"]

    for id, header in headers.items():
        if (
            header["level"] == level + 1
            and id not in children
            and header["parent"] == header_id
        ):
            children.append(id)

    return children


def extract_headings(md_content: str):
    """Extract heading hierarchy from Markdown content.
    Args:
        md_content (str): Markdown content.
    Returns:
        Json object contains the heading hierarchy
    """
    header_index = 0
    headers = {}
    lines = md_content.split("\n")
    id_index_dict = {}
    for line in lines:
        match = re.match(r"(#+)(.*)", line)
        if match:
            header_index += 1
            print(match.group)
            level = len(match.group(1))
            title = match.group(2).strip()
            id_prefix = str(uuid.uuid4())[:8]
            _id = f"${header_index}-{id_prefix}"
            parent = find_parent(headers, level)
            previous = find_previous_with_same_level(headers, level)
            headers[_id] = {
                "title": title,
                "level": level,
                "parent": parent,
                "previous": previous,
            }
            # Use list in case multiple heading have the same title
            if title not in id_index_dict:
                id_index_dict[title] = [_id]
            else:
                id_index_dict[title].append(_id)

    for header_obj in headers:
        headers[header_obj]["child"] = find_child(headers, header_obj)
        headers[header_obj]["next"] = find_next_with_same_level(headers, header_obj)

    return headers, id_index_dict


class MarkdownHeaderTextSplitter:
    # Place holder for now without parameters
    def __init__(self, res_bucket: str = None):
        self.res_bucket = res_bucket

    def _is_markdown_header(self, line):
        header_pattern = r"^#+\s+"
        if re.match(header_pattern, line):
            return True
        else:
            return False

    def _is_markdown_table_row(self, line):
        return re.fullmatch(r"\|.*\|.*\|", line) is not None
    
    def _set_chunk_id(self, id_index_dict: dict, current_heading: str, metadata: dict, same_heading_dict: dict):
        """Set chunk id when there are multiple headings are the same.
        Eg. 
        # Heading 1
        ## Same heading
        # Heading 2
        ## Same heading

        Args:
            id_index_dict (dict): Id and index mapping
            current_heading (str): Current heading
            metadata (dict): Metadata
            same_heading_dict (dict): Same heading mapping
        """
        if 1 == len(id_index_dict[current_heading]):
            metadata["chunk_id"] = id_index_dict[current_heading][0]
        elif len(id_index_dict[current_heading]) > 1:
            # If multiple headings are the same in the document,
            # use index in same_heading_dict to get the chunk_id
            if current_heading not in same_heading_dict:
                same_heading_dict[current_heading] = 0
                metadata["chunk_id"] = id_index_dict[current_heading][0]
            else:
                # Move one step to get the next chunk_id
                same_heading_dict[current_heading] += 1
                print(same_heading_dict[current_heading])
                if len(id_index_dict[current_heading]) > same_heading_dict[current_heading]:
                    metadata["chunk_id"] = id_index_dict[current_heading][
                        same_heading_dict[current_heading]
                    ]
                else:
                    print("id index dict =============")
                    print(id_index_dict)
                    print("current heading ====================")
                    print(current_heading)
                    print("same heading dict ===========")
                    print(same_heading_dict)
                    id_prefix = str(uuid.uuid4())[:8]
                    metadata["chunk_id"] = f"$0-{id_prefix}"
                

    def split_text(self, text: Document) -> List[Document]:
        # if self.res_bucket is not None:
        #     save_content_to_s3(s3, text, self.res_bucket, SplittingType.BEFORE.value)
        # else:
        #     logger.error(
        #         "No resource bucket is defined, skip saving content into S3 bucket"
        #     )

        lines = text.page_content.strip().split("\n")
        chunks = []
        current_chunk_content = []
        same_heading_dict = {}
        table_content = []
        inside_table = False
        heading_hierarchy, id_index_dict = extract_headings(text.page_content.strip())
        if len(lines) > 0:
            current_heading = lines[0]

        for line in lines:
            # Replace escaped characters for table markers
            line = line.strip()
            line = line.replace(r"\begin{table}", "\\begin{table}").replace(
                r"\end{table}", "\\end{table}"
            )
            if line in ["\\begin{table}", "\\end{table}"]:
                continue

            if self._is_markdown_header(line):  # Assuming these denote headings
                # Save the current chunk if it exists
                if current_chunk_content:
                    metadata = text.metadata.copy()
                    metadata["content_type"] = "paragragh"
                    metadata["heading_hierarchy"] = heading_hierarchy
                    metadata["current_heading"] = current_heading
                    current_heading = current_heading.replace("#", "").strip()
                    try:
                        self._set_chunk_id(id_index_dict, current_heading, metadata, same_heading_dict)
                    except KeyError:
                        logger.info(
                            f"No standard heading found, check your document with {current_chunk_content}"
                        )
                        id_prefix = str(uuid.uuid4())[:8]
                        metadata["chunk_id"] = f"$0-{id_prefix}"
                    chunks.append(
                        Document(
                            page_content="\n".join(current_chunk_content),
                            metadata=metadata,
                        )
                    )
                    current_chunk_content = []  # Reset for the next chunk
                current_heading = line

            if self._is_markdown_table_row(line):
                inside_table = True
            elif inside_table:
                # The first line under a table
                inside_table = False
                # Save table content as a separate document
                if table_content:
                    metadata = text.metadata.copy()
                    metadata["content_type"] = "table"
                    metadata["heading_hierarchy"] = heading_hierarchy
                    metadata["current_heading"] = current_heading
                    current_heading = current_heading.replace("#", "").strip()
                    try:
                        self._set_chunk_id(id_index_dict, current_heading, metadata, same_heading_dict)
                    except KeyError:
                        print(f"No standard heading found")
                        id_prefix = str(uuid.uuid4())[:8]
                        metadata["chunk_id"] = f"$0-{id_prefix}"
                    chunks.append(
                        Document(
                            page_content="\n".join(table_content), metadata=metadata
                        )
                    )
                    table_content = []  # Reset for the next table

            if inside_table:
                table_content.append(line)
            else:
                current_chunk_content.append(line)

        # Save the last chunk if it exists
        if current_chunk_content:
            metadata = text.metadata.copy()
            metadata["content_type"] = "paragragh"
            metadata["heading_hierarchy"] = heading_hierarchy
            metadata["current_heading"] = current_heading
            current_heading = current_heading.replace("#", "").strip()
            try:
                self._set_chunk_id(id_index_dict, current_heading, metadata, same_heading_dict)
            except KeyError:
                logger.info(f"No standard heading found")
                id_prefix = str(uuid.uuid4())[:8]
                metadata["chunk_id"] = f"$0-{id_prefix}"
            chunks.append(
                Document(
                    page_content="\n".join(current_chunk_content), metadata=metadata
                )
            )

        return chunks

# Open the file
with open('/Users/lvning/Downloads/2023-12-20-08-41-06-318762.md', 'r') as file:
    # Read the file
    content = file.read()

print("=============Origin document=============")
print(content)

# Markdown loader
loader = CustomMarkdownLoader(aws_path=f"s3://byoc-test-2023/CBCT功能介绍-最新彩页.docx")
doc = loader.load(content)
# Doc loader
# loader = CustomDocLoader(file_path="/Users/lvning/Downloads/E1 用户手册_ocr.docx", aws_path="s3://test/a")
# doc = loader.load()
splitter = MarkdownHeaderTextSplitter()
doc_list = splitter.split_text(doc)
for doc_item in doc_list:
    print("=====================")
    print(doc_item)

