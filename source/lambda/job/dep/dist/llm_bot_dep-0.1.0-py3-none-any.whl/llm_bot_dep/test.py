#
import re

file_path = "/home/ubuntu/icyxu/code/solutions/Intelli-Agent/source/lambda/job/dep/llm_bot_dep/FAQ-broker.md.txt"

with open(file_path, "r") as file:
    text_content = file.read()


def pre_process_text(text_content: str) -> str:
    # Clean up text content
    text_content = re.sub(r"[^\S\n]+", " ", text_content)
    text_content = re.sub(r"\n+", "\n", text_content)

    return text_content.strip()


print(pre_process_text(text_content))
