import mimetypes
import shutil
import tempfile

import requests

img_path = "https://d1.awsstatic.com/reInvent/reinvent-2024/amazon-sagemaker/sagemaker_marketecture_final.1284e8075b373120403f8758cfbee2ad507973c1.jpg"

if img_path.startswith(("http://", "https://")):
    try:
        # Download image using requests
        response = requests.get(img_path, timeout=10)
        response.raise_for_status()

        # Determine file extension from Content-Type header
        content_type = response.headers.get("Content-Type", "")
        ext = mimetypes.guess_extension(content_type) or ".jpg"

        # Fallback to URL path if needed
        if ext == ".jpe":  # Fix common mimetypes quirk
            ext = ".jpg"

        # Create temporary file with proper extension
        temp_file = tempfile.NamedTemporaryFile(suffix=ext, delete=False)
        temp_file.write(response.content)
        temp_file.close()
        img_path = temp_file.name
    except Exception as e:
        pass

# move figure to /home/ubuntu/icyxu/code/solutions/Intelli-Agent/source/lambda/job/dep/llm_bot_dep
shutil.move(img_path, "/home/ubuntu/icyxu/code/solutions/Intelli-Agent/source/lambda/job/dep/llm_bot_dep")
