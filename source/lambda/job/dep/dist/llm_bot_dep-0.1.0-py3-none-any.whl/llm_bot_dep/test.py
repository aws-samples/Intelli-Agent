from sm_utils import create_embeddings_with_m3_model

embedding_model_endpoint = "embedding-bge-m3-3ab71"
region = "us-west-2"
embedding_function = create_embeddings_with_m3_model(embedding_model_endpoint, region)


embeddings_vectors = embedding_function.embed_documents(["你好", "你好"])
print(embeddings_vectors)
