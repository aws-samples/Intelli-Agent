import base64
import json
import logging
from pathlib import Path

import boto3
from langchain.docstore.document import Document
from langchain.document_loaders.base import BaseLoader
from llm_bot_dep.figure_llm import figureUnderstand, upload_image_to_s3
from llm_bot_dep.splitter_utils import MarkdownHeaderTextSplitter

bedrock_client = boto3.client("bedrock-runtime")
logger = logging.getLogger(__name__)


def get_api_key(api_secret_name):
    """
    Get the API key from AWS Secrets Manager.

    Args:
        api_secret_name (str): The name of the secret in AWS Secrets Manager containing the API key.

    Returns:
        str: The API key.
    """
    try:
        # Create a Secrets Manager client
        secrets_client = boto3.client("secretsmanager")
        # Get the secret value
        secret_response = secrets_client.get_secret_value(
            SecretId=api_secret_name
        )
        # Parse the secret JSON
        if "SecretString" in secret_response:
            secret_data = json.loads(secret_response["SecretString"])
            api_key = secret_data.get("key")
            logger.info(
                f"Successfully retrieved API key from secret: {api_secret_name}"
            )
            return api_key
    except Exception as e:
        logger.error(f"Error retrieving secret {api_secret_name}: {str(e)}")
    return None


class CustomImageLoader(BaseLoader):
    """Load image file such as png, jpeg, jpg."""

    def __init__(
        self,
        s3_client,
        aws_path: str,
        file_type: str,
    ):
        """Initialize with S3 parameters."""
        self.s3_client = s3_client
        self.aws_path = aws_path
        self.file_type = file_type

    def load(self, bucket_name: str, file_name: str, **kwargs) -> Document:
        """Load directly from S3."""
        # Parse bucket and key from aws_path
        # aws_path format: s3://bucket-name/path/to/key
        aws_path = self.aws_path.replace("s3://", "")
        path_parts = aws_path.split("/", 1)
        s3_bucket = path_parts[0]
        s3_key = path_parts[1]

        # Read image from S3
        response = self.s3_client.get_object(Bucket=s3_bucket, Key=s3_key)
        image_bytes = response["Body"].read()
        encoded_image = base64.b64encode(image_bytes).decode("utf-8")
        model_provider = kwargs.get("model_provider")
        model_id = kwargs.get("model_id")
        api_secret_name = kwargs.get("api_secret_name")
        api_url = kwargs.get("api_url")

        if api_secret_name:
            api_key = get_api_key(api_secret_name)
        else:
            api_key = None

        # Initialize figureUnderstand and process image
        figure_llm = figureUnderstand(
            model_provider=model_provider,
            model_id=model_id,
            api_url=api_url,
            api_key=api_key,
        )
        # Using empty context and generic tag since we're processing standalone images
        understanding = figure_llm.figure_understand(
            img=encoded_image, context="", tag="[IMAGE]", s3_link="0.jpg"
        )

        # Upload image directly using image_bytes
        object_key = upload_image_to_s3(
            image_bytes, bucket_name, file_name, "image", 0, is_bytes=True
        )
        understanding = understanding.replace(
            "<link>0.jpg</link>", f"<link>{object_key}</link>"
        )
        logger.info("Generated understanding: %s", understanding)
        metadata = {"file_path": self.aws_path, "file_type": self.file_type}

        return Document(page_content=understanding, metadata=metadata)


def process_image(s3, **kwargs):
    bucket_name = kwargs["bucket"]
    key = kwargs["key"]
    portal_bucket_name = kwargs["portal_bucket_name"]
    file_type = kwargs["image_file_type"]
    file_name = Path(key).stem
    loader = CustomImageLoader(
        s3_client=s3,
        aws_path=f"s3://{bucket_name}/{key}",
        file_type=file_type,
    )
    doc = loader.load(portal_bucket_name, file_name, **kwargs)
    splitter = MarkdownHeaderTextSplitter(kwargs["res_bucket"])
    doc_list = splitter.split_text(doc)

    return doc_list
