# give final response tool

def give_final_response(response: str):
    return response
