# give rhetorical question

def give_rhetorical_question(question: str):
    return question
