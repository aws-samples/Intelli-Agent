
async def run_coroutine_task(task):
    return await task
