# give chat response

def chat(response: str):
    return response
