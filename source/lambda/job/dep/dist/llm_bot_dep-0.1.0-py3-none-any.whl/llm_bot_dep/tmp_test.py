import os
import sys

print(sys.path)

import sm_utils

embeddingModelEndpoint = "bge-m3-2024-03-05-07-28-21-582-endpoint"
region = "us-west-2"
file_type = "csv"

embeddings = sm_utils.create_embeddings_with_m3_model(
    embeddingModelEndpoint, region, file_type
)

texts = ["hi", "hi"]
print(list(texts))

embeddings_vectors = embeddings.embed_documents(list(texts))
print(embeddings_vectors)

print(len(embeddings_vectors))
print(f"type of embeddings_vectors[0]: {type(embeddings_vectors[0])}")
print(f"keys of embeddings_vectors[0]: {embeddings_vectors[0].keys()}")
print(
    f"len of embeddings_vectors[0]['dense_vecs']: {len(embeddings_vectors[0]['dense_vecs'])}"
)
