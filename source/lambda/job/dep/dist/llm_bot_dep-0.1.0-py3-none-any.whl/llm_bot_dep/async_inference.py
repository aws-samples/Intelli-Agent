import json
import logging
import os
import re
import boto3
import uuid
import datetime
from botocore.exceptions import ClientError
from urllib.parse import urlparse
import time
from smart_open import open as smart_open


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

s3_client = boto3.client("s3")
smr_client = boto3.client("sagemaker-runtime")
# Max retry is 2 hours
_S3_FETCH_MAX_RETRY = 3600
_S3_FETCH_WAIT_TIME = 5


def invoke_etl_model(
    etl_model_endpoint,
    bucket: str,
    key: str,
    res_bucket: str,
    mode: str="ppstructure",
    lang: str="zh",
):
    json_data = {
        "s3_bucket": bucket,
        "object_key": key,
        "destination_bucket": res_bucket,
        "mode": mode,
        "lang": lang,
    }

    file_name = f"data_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex}.json"

    # Save JSON data to a file
    with open(file_name, "w") as json_file:
        json.dump(json_data, json_file)

    s3_file_path = "inference/" + file_name
    # Upload the file to S3
    s3_client.upload_file(file_name, res_bucket, s3_file_path)
    logger.info(f"JSON data uploaded to S3 bucket: {res_bucket}/{s3_file_path}")

    response = smr_client.invoke_endpoint_async(
        EndpointName=etl_model_endpoint,
        ContentType="application/json",
        InputLocation=f"s3://{res_bucket}/{s3_file_path}",
    )
    logger.info("This is the async response:")
    logger.info(response)
    inference_id = response["InferenceId"]
    output_location = response["OutputLocation"]

    fetch_count = 0
    while fetch_count < _S3_FETCH_MAX_RETRY:
        if _s3_uri_exist(output_location):
            logger.info("ETL inference completed")
            output = json.load(smart_open(output_location))

            return output["destination_prefix"]
        else:
            logger.info("Waiting for ETL output...")
            fetch_count = fetch_count + 1
            time.sleep(_S3_FETCH_WAIT_TIME)

    raise Exception("Unable to fetch ETL inference result, and the number of retries reached.")


endpoint_name = "etl-endpoint"
bucket_name = "byoc-test-2023"
key = "华鼎股份：义乌华鼎锦纶股份有限公司关于2024年远期结售汇额度的公告.pdf"
res_bucket = "llm-bot-dev-etlstackneste-llmbotglueresultbucket79-jgo50rvzlclp"
response = invoke_etl_model(endpoint_name, bucket_name, key, res_bucket)

logger.info(response)


def load_content_from_s3(s3, bucket, key):
    """
    This function loads the content of a file from S3 and returns it as a string.
    """
    logger.info(f"Loading content from s3://{bucket}/{key}")
    obj = s3.get_object(Bucket=bucket, Key=key)
    return obj["Body"].read().decode("utf-8")

