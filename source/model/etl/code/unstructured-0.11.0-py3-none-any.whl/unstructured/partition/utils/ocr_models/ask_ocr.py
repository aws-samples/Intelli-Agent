import os
import functools

from unstructured.logger import logger
from unstructured.partition.utils.ocr_models.general_ocr import ocr_main

@functools.lru_cache(maxsize=None)
def load_agent(model_path = ""):

    if not model_path:
        logger.error("Model path is not provided")
        model_path = os.getenv("DEFAULT_ASK_MODEL_PATH", "/opt/ml/model/ocr_model/")
    
    try:
        ask_ocr = ocr_main.TextSystem(model_path = model_path)
    except AttributeError:
        ask_ocr = None
        # Raise an error
        raise AttributeError("ASK OCR agent is not loaded")
    return ask_ocr
