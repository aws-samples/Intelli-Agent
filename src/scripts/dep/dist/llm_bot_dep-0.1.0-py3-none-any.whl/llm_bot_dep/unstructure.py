from langchain.document_loaders import UnstructuredPDFLoader
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# local pdf file in current folder
loader = UnstructuredPDFLoader('paperSnapshot.pdf')
data = loader.load()

logger.info("text: %s", data[0])
