import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

metadata_template = {
"content_type": "paragraph",
"heading_hierarchy": {},
"figure_list": [],
"chunk_id": "$$",
"file_path": "",
"keywords": [],
"summary": "",
}

markdown_document = """
# Learning to Retrieve In-Context Examples for Large Language Models
###### Abstract
aaaa
## 1 Introduction
1111
## 2 Related Work
2222
## 3 Preliminaries
3333
## 4 Methodology
4444
### Training Data Generation
5555
### Reward Modeling
6666
### Training LLM Retrievers with Knowledge Distillation
7777
### Evaluation of LLM Retrievers
8888
|-|-|
|:--:|:--:|
## 5 Experiments
### Evaluation Setup
9999
### Main Results
0000
### Training Pipeline of LLM-R
1010
### Generalization Ability of LLM-R
1212
### When does LLM-R Work and When Does it Not?
1313
### Using Different LLMs for Data Generation and Task Evaluation
1414
### Scaling the Number of In-Context Examples and Retriever Size
1515
## 7 Conclusion
1616
## Limitations
1717
## References
1818
"""

def unstructured_loader(file_path: str):
    # benchmark the unstructured package
    from langchain.document_loaders import UnstructuredFileLoader
    loader = UnstructuredFileLoader("./2.pdf")
    docs = loader.load()
    logger.info(f"docs: {docs[0].page_content}")

def nougat_loader():
    # benchemark the nougat package
    # nougat ./2.pdf -o . --full-precision --markdown -m 0.1.0-base --recompute
    pass

def llamaIndex_loader(file_path: str):
    try:
        import pypdf
    except ImportError:
        raise ImportError(
            "pypdf is required to read PDF files: `pip install pypdf`"
        )
    with open(file_path, "rb") as fp:
        # Create a PDF object
        pdf = pypdf.PdfReader(fp)

        # Get the number of pages in the PDF document
        num_pages = len(pdf.pages)

        # Iterate over every page
        docs = []
        for page in range(num_pages):
            # Extract the text from the page
            page_text = pdf.pages[page].extract_text()
            page_label = pdf.page_labels[page]

            metadata = {"page_label": page_label, "file_name": file_path}
            logger.info("page_text: {}, page_label: {}".format(page_text, page_label))

def markdown_header_splitter():
    from splitter_utils import MarkdownHeaderTextSplitter, Document
    markdown_splitter = MarkdownHeaderTextSplitter()
    # construct a fake document data
    data = [Document(page_content=markdown_document, metadata=metadata_template)]
    md_header_splits = markdown_splitter.split_text(data[0])
    for i, doc in enumerate(md_header_splits):
        logger.info("content of chunk %s: %s", i, doc)

# main entry point
if __name__ == "__main__":
    # llamaIndex_loader("2.pdf")
    markdown_header_splitter()
